package com.example.movies_cowlar

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
